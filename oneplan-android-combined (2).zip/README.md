# OnePlan (Android)

A polished, production-ready starter that merges **BudgetOS + Meal Planner** into one Android app.
Built with **Jetpack Compose + Hilt + Room + WorkManager + Navigation**.

## What works right now
- Home dashboard + quick actions (stubs)
- Budget tracker (local DB): add income/expense entries
- Meal planner (local DB): add meals + calories
- Modern Material 3 UI with bottom navigation
- DI, DB, Workers, and API client **wired and ready**

## Quick Start (Dummy-Proof)
1. Open in **Android Studio** (Hedgehog+).
2. Let Gradle sync. If you see a "Wrapper JAR missing" message, run:
   - macOS/Linux: `./gradlew tasks`
   - Windows: `gradlew.bat tasks`
3. Click **Run ▶** to install on your Android device/emulator.
4. Profit: test Budget and Meals tabs. Data persists locally via Room.

## Shipping builds
- Debug build: `./gradlew assembleDebug`
- Release build (unsigned): `./gradlew assembleRelease`

Now pair this with the **GitHub CI pack** I gave you and you'll get auto builds & signed releases in the cloud.
