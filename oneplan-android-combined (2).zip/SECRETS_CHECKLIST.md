# OnePlan — Secrets Checklist (GitHub → Settings → Secrets and variables → Actions)

Create these **Repository secrets**:

- `ANDROID_KEYSTORE_BASE64` — The **base64 text** of your keystore file (see README for encoding commands).
- `KEYSTORE_PASSWORD` — The password you set when creating the keystore.
- `KEY_ALIAS` — The alias you chose (e.g., `oneplan`).
- `KEY_PASSWORD` — The key password (can be same as keystore password).

**Tips**
- The base64 string should be **one single line** (no spaces/newlines).
- Never commit keystores or passwords to git.
