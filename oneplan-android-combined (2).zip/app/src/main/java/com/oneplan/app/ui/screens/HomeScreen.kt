package com.oneplan.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun HomeScreen(
    onQuickAddIncome: () -> Unit,
    onQuickAddExpense: () -> Unit,
    onQuickAddMeal: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("OnePlan", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Your daily hub for money, meals, and momentum.", style = MaterialTheme.typography.bodyMedium)

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = onQuickAddIncome) { Text("Add Income") }
            Button(onClick = onQuickAddExpense) { Text("Add Expense") }
            Button(onClick = onQuickAddMeal) { Text("Add Meal") }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Today’s Snapshot", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(8.dp))
                Text("• Balance: $0.00 (demo)
• Calories planned: 0
• Tasks: 0")
            }
        }
    }
}
