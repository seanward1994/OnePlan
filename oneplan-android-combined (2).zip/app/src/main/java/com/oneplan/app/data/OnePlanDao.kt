package com.oneplan.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface OnePlanDao {
    // Budget
    @Query("SELECT * FROM BudgetEntry ORDER BY timestamp DESC")
    fun budgetStream(): Flow<List<BudgetEntry>>
    @Insert
    suspend fun insertBudget(item: BudgetEntry)
    @Delete
    suspend fun deleteBudget(item: BudgetEntry)

    // Meals
    @Query("SELECT * FROM MealPlan ORDER BY timestamp DESC")
    fun mealsStream(): Flow<List<MealPlan>>
    @Insert
    suspend fun insertMeal(item: MealPlan)
    @Delete
    suspend fun deleteMeal(item: MealPlan)
}
