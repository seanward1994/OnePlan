package com.oneplan.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class BudgetEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val amount: Double,
    val type: String, // "income" or "expense"
    val timestamp: Long = System.currentTimeMillis()
)

@Entity
data class MealPlan(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val day: String,
    val meal: String,
    val calories: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
)
