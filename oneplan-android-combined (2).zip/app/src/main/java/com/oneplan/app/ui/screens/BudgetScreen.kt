package com.oneplan.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.oneplan.app.data.BudgetEntry

@Composable
fun BudgetScreen(
    items: List<BudgetEntry>,
    onAdd: (String, Double, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("income") }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Budget", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = amount, onValueChange = { amount = it }, label = { Text("Amount") }, modifier = Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = type=="income", onClick = { type="income" }, label = { Text("Income") })
            FilterChip(selected = type=="expense", onClick = { type="expense" }, label = { Text("Expense") })
            Button(onClick = {
                val amt = amount.toDoubleOrNull() ?: 0.0
                if (title.isNotBlank() && amt != 0.0) onAdd(title, amt, type)
                title=""; amount=""
            }) { Text("Add") }
        }
        Spacer(Modifier.height(12.dp))
        Divider()
        LazyColumn {
            items(items) { itx ->
                ListItem(
                    headlineContent = { Text(itx.title) },
                    supportingContent = { Text("${itx.type} — $${itx.amount}") }
                )
                Divider()
            }
        }
    }
}
