package com.oneplan.app.data

import kotlinx.coroutines.flow.Flow

interface OnePlanRepository {
    val budgets: Flow<List<BudgetEntry>>
    val meals: Flow<List<MealPlan>>
    suspend fun addBudget(title: String, amount: Double, type: String)
    suspend fun addMeal(day: String, meal: String, calories: Int)
}

class OnePlanRepositoryImpl(private val db: AppDatabase): OnePlanRepository {
    private val dao = db.dao()
    override val budgets: Flow<List<BudgetEntry>> = dao.budgetStream()
    override val meals: Flow<List<MealPlan>> = dao.mealsStream()

    override suspend fun addBudget(title: String, amount: Double, type: String) {
        dao.insertBudget(BudgetEntry(title = title, amount = amount, type = type))
    }

    override suspend fun addMeal(day: String, meal: String, calories: Int) {
        dao.insertMeal(MealPlan(day = day, meal = meal, calories = calories))
    }
}
