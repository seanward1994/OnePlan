package com.oneplan.app.navigation

sealed class Route(val path: String) {
    data object Home: Route("home")
    data object Budget: Route("budget")
    data object Meals: Route("meals")
    data object Settings: Route("settings")
}
