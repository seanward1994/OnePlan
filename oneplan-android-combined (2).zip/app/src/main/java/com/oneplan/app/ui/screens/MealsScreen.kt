package com.oneplan.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.oneplan.app.data.MealPlan

@Composable
fun MealsScreen(
    items: List<MealPlan>,
    onAdd: (String, String, Int) -> Unit
) {
    var day by remember { mutableStateOf("Today") }
    var meal by remember { mutableStateOf("") }
    var calories by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Meals", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = day, onValueChange = { day = it }, label = { Text("Day") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = meal, onValueChange = { meal = it }, label = { Text("Meal") }, modifier = Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = calories, onValueChange = { calories = it }, label = { Text("Calories") }, modifier = Modifier.weight(1f))
            Button(onClick = {
                val cal = calories.toIntOrNull() ?: 0
                if (meal.isNotBlank()) onAdd(day, meal, cal)
                meal=""; calories=""
            }) { Text("Add") }
        }
        Spacer(Modifier.height(12.dp))
        Divider()
        LazyColumn {
            items(items) { itx ->
                ListItem(
                    headlineContent = { Text("${itx.day}: ${itx.meal}") },
                    supportingContent = { Text("Calories: ${itx.calories}") }
                )
                Divider()
            }
        }
    }
}
