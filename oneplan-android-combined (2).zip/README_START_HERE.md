# OnePlan — GitHub Auto Build Pack (Android)

**What you get**
- CI that builds your Android debug APK and runs tests on every push/PR.
- A release workflow that **signs** your APK and **publishes a GitHub Release** when you push a tag (e.g., `v0.1.0`) or run it manually.
- Dependabot to keep Gradle deps and GitHub Actions up to date.

> Drop these files at the **root of your Android repo** (same level as `gradlew`). Commit + push and you're rolling.

---

## 2‑Minute Setup

1) **Drag & Drop**
- Copy the `.github/` folder from this pack into the **root** of your Android project (where `gradlew` lives).
- Add `README_START_HERE.md` and `SECRETS_CHECKLIST.md` too (optional).

2) **Commit & Push**
```bash
git add .github README_START_HERE.md SECRETS_CHECKLIST.md
git commit -m "chore(ci): bootstrap OnePlan Android CI/CD"
git push origin main
```

3) **Add Repository Secrets (Signing)**
- Go to **GitHub → Settings → Secrets and variables → Actions → New repository secret**.
- Add the four secrets listed in `SECRETS_CHECKLIST.md`.

4) **Trigger Builds**
- **Debug build**: any push to `main`/`master` → check **Actions** → job → **Artifacts** → download `oneplan-debug-apks`.
- **Release build**: push a tag like `v0.1.0` **or** run **Actions → OnePlan Android Release → Run workflow**.
  - Output: signed APK uploaded as an artifact **and** attached to a **GitHub Release**.

That’s it. You can close the laptop—Actions run in the cloud.

---

## Keystore: Create & Encode (once)

> **Never commit your keystore.** Store it locally and paste the **base64 string** into a GitHub Secret.

### Create a keystore (Android Studio comes with `keytool`)
Choose your own passwords, names, and validity:

```bash
keytool -genkeypair -v -keystore oneplan.keystore -alias oneplan   -keyalg RSA -keysize 2048 -validity 10000   -dname "CN=OnePlan, OU=Dev, O=OnePlan, L=Lafayette, S=IN, C=US"
```

### Base64‑encode the keystore

**macOS/Linux**
```bash
base64 -w 0 oneplan.keystore > keystore.base64.txt   # macOS: `base64 oneplan.keystore > keystore.base64.txt`
```

**Windows PowerShell**
```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes("C:\path\to\oneplan.keystore")) > keystore.base64.txt
```

Open `keystore.base64.txt`, copy **all** text, and paste it into the `ANDROID_KEYSTORE_BASE64` secret.

---

## Change app module (if not `app`)
- Default module is `app`. If your module name is different, either:
  - When running the release workflow, set **module** input to your module name, or
  - Edit `.github/workflows/release.yml` and change `MODULE_PATH`.

---

## Common fixes
- **Gradle wrapper permission**: CI step already runs `chmod +x ./gradlew`.
- **Signing failed / Missing secrets**: ensure all 4 secrets are present and correct, with no line breaks in the base64 string.
- **APK path**: if your module isn’t `app`, adjust the `MODULE_PATH` or the artifact glob `**/build/outputs/apk/...`.

---

## What’s included
- `.github/workflows/android-ci.yml` — debug build + tests + artifact.
- `.github/workflows/release.yml` — sign & release on tag or manual run.
- `.github/dependabot.yml` — weekly dep updates.

> Name locked: **OnePlan** ✅
